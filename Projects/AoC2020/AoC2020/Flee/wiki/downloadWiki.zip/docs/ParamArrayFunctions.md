**Calling functions with a variable number of arguments**

Flee supports calling functions with a variable number of arguments.  Flee will detect calls to functions marked with the {{params}} keyword and will package all given arguments into an array of the params type.

Here's an example that shows how to do this:

{{
// Declare a class with some static functions
public static class CustomFunctions
{
   // Declare a function that takes a variable number of arguments
   public static int Sum(params int[]() args)
   {
      int sum = 0;

      foreach (int i in args)
         sum += i;

      return sum;
   }
}
}}

Once we have declared the function, we can use it in an expression:

{{
ExpressionContext context = new ExpressionContext();
context.Imports.AddType(typeof(CustomFunctions));

IDynamicExpression e = context.CompileDynamic("sum(1,2,3,4,5,6)");
int result = (int)e.Evaluate();
}}