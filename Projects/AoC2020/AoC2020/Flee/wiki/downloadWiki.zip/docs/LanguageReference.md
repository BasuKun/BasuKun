**Language Reference**

The expression language that Flee uses is a mix of elements of C# and VB.Net. Since the aim of this library is speed, the language is strongly typed (same rules as C#) and there is no late binding. Unlike C#, the language is **not** case-sensitive.

**Contents**
* [#ArithmeticOperators](#ArithmeticOperators)
* [#ComparisonOperators](#ComparisonOperators)
* [#AndOrXorNotOperators](#AndOrXorNotOperators)
* [#ShiftOperators](#ShiftOperators)
* [#Concatenation](#Concatenation)
* [#Indexing](#Indexing)
* [#Literals](#Literals)
* [#Casting](#Casting)
* [#ConditionalOperator](#ConditionalOperator)
* [#InOperator](#InOperator)
* [Overloaded Operators On Types](#OverloadedOperatorsOnTypes)

**Arithmetic Operators**{anchor:ArithmeticOperators}
Flee supports all the standard arithmetic operators as well as the modulo (%) and power (^) operators.
Example: {{a*2 + b ^ 2 - 100 % 5}}

**ComparisonOperators**{anchor:ComparisonOperators}
All the comparison operators are supported as well.  The not equal operator is {{<>}} and the equal operator is {{=}}
Example: {{a <> 100}}

**And/Or/Xor/Not Operators**{anchor:AndOrXorNotOperators}
Flee uses these operators for both logical and bitwise operations.  Since the expression language is strongly-typed, Flee can determine the types of the operands to these operators.  If both operands are booleans, then the operation is logical.  If both are integral, the operation is bitwise.  Any other combination results in a compile error.
Example (logical): {{a > 100 And Not b = 100}}
Example (bitwise): {{(100 or 2) and 1}}

**Shift Operators**{anchor:ShiftOperators}
The left (<<) and right (>>) shift operators do a bitwise shift and are only valid on integral types.
Example: {{100 >> 2}}

**Concatenation**{anchor:Concatenation}
The + operator also serves as the string concatenation operator.  If either of its operands is a string, it will perform a concatenate instead of an addition.  It is valid for only one operand to be a string in which case, both operands are converted to Object and formatted accordingly.
Example: {{"abc" + "def"}}
Example: {{"the number is: " + 100}}

**Indexing**{anchor:Indexing}
The indexing operator takes the form: {{member[indexExpression](indexExpression)}}.  Any expression can appear inside the brackets.  If the member being indexed is an array, Flee will emit optimized array element loading instructions.  If the indexed member has a default indexer property, flee will call the property with the evaluated index.  Indexing a type which is not an array and does not have a default indexer generates a compile exception.
Example: {{arr[i + 1](i-+-1) + 100}}

**Literals**{anchor:Literals}
Flee supports the following literals in expressions:
* **Char** - A character in single quotes: {{'a'}}
* **Boolean** - Either {{true}} or {{false}}
* **Real** - Any number with a decimal point.  You can use the 'd', 'f', or 'm' suffixes to specify whether the number should be stored in a double, single, or decimal respectively.  Use the ExpressionOptions.RealLiteralDataType option to specify the data type used to store the number when no suffix is specified.  The default is double.
* **Integral** - Any number without a decimal point.  Append "L" to force the number to a 64-bit integer and/or a "U" to force it to unsigned.  Flee will try to assign an integer literal to the first integral type that can contain the value.
* **Hex** - Integral constants can also be specified in hex notation: {{0xFF12}}
* **String** - String literals are enclosed in double quotes and escaping characters follows the same rules as C#: {{"string\u0021\r\n a \"new\" line"}}
* **Null** - Using the keyword {{null}} will load the null reference into an expression.
* **DateTime** - A valid .NET DateTime pattern surrounded by #'s.  Use the {{ExpressionOptions.DateTimeFormat}} property to control the format.  Example:  {{#08/06/2008#.ToLongDateString()}}
* **TimeSpan** - A string in the format {{##[d.](d.)hh:mm[:ss[.ff](_ss[.ff)]#}}.  Example: {{#08/06/2008# + ##1.23:45#}}

**Casting**{anchor:Casting}
Casting is performed using the special cast function which takes the form {{cast(value, type)}}.
Example: {{100 + cast(obj, int)}}

**Conditional Operator**{anchor:ConditionalOperator}
Flee supports a conditional operator that allows you to pick a result based on a boolean condition.  It is implemented as a special function of the form {{if(condition, whenTrue, whenFalse)}}.  The operator is a "true" conditional operator: only the expression that matches the condition is evaluated.
Example: {{If(a > 100 and b > 10, "both greater", "less")}}

**In Operator**{anchor:InOperator}
The In operator is a boolean binary operator that returns true if its first operand is contained in its second operand.  It has two forms
* **List**: Searches a list of values for a given value: {{value IN (value1, value2, value3,...)}}.  The value is compared against each value in the list and {{true}} is returned if the value is found, {{false}} if no match is found.
* **Collection**: Searches a single collection for a given value: {{value IN collection}}.  The collection variable must implement {{ICollection<T>}}, {{IDictionary<K,V>}}, {{IList}}, or {{IDictionary}} for the expression to compile.  Arrays can be searched with this operator as they implement the first interface.

Example (List): {{If(100 in (100, 200, 300, -1), "in", "not in")}}
Example (Collection): {{if(100 in collection, "in", "not in")}}

**Overloaded Operators On Types**{anchor:OverloadedOperatorsOnTypes}
When evaluating an arithmetic, comparison, or conversion operation where the operands are not primitives, Flee will look for and use any overloaded operators defined on the operands.  This means that you can create expressions such as {{a + b}} (where a and b are custom types), as long as there is an addition operator defined on either operand.