**Frequently Asked Questions**

**When I create an expression such as {{1/2}}, why is the result 0 instead of 0.5?**
When an arithmetic operation involves two integers, the result will be an integer.  If either or both operands are floating-point, then the result will be floating-point.  In the above case, since both operands are integers, an integer division is performed and yields 0.  This is a performance feature which makes sure that expressions that perform arithmetic involving only integers will use the more efficient and faster integer instructions.

Workarounds:
* Make either operand a real number: 1/2.0 or 1.0/2
* Use the {{ExpressionOptions.IntegersAsDoubles}} option to force Flee to treat all integer literals as doubles.  With this option set, {{1/2}} will evaluate to 0.5.

**Why do I get compile exceptions when I call functions with multiple real number arguments and my culture uses ',' as the decimal separator (ie: sum(1,23, 4,56))?**
When the decimal separator for real numbers is set to ',', Flee has to use a different character as the argument delimiter for functions otherwise the grammar becomes ambiguous.  To avoid the ambiguity, Flee uses the list separator character from the parse culture as the delimiter for function arguments.

Example:
en-US: {{sum(1.23, 4.56)}}
fr-FR: {{sum(1,23; 4,56)}}

If you really want to use ',' for both the decimal separator and function arguments, you can set the {{ExpressionContext.ParserOptions.RequireDigitsBeforeDecimalPoint}} property to true.  This will require all real numbers to have a digit before the decimal point (ie: 0.45 instead of .45) but will eliminate the grammar ambiguity.