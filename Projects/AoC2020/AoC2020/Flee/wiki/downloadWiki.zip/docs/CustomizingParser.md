Flee allows customization of its expression parser.  Customizing the parser is done through the {{ExpressionContext.ParserOptions}} property.  You set the properties to the values you want and then call {{RecreateParser}} to apply your changes.

Here's an example:
{{
ExpressionContext context = new ExpressionContext();
context.Imports.AddType(typeof(Math))

context.CompileDynamic("max(1.23, 4.56)", context);

context.ParserOptions.DecimalSeparator = ',';
context.ParserOptions.FunctionArgumentSeparator = ';';
context.RecreateParser();

context.CompileDynamic("max(1,23; 4,56)", context);
}}