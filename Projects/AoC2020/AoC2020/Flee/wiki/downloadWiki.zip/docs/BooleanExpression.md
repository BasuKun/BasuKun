**Evaluating Boolean Expressions**

One popular use of Flee is to use expressions as filters or predicates by evaluating boolean conditions.  When using Flee in this way, we can create generic expressions since we know that the result is always a boolean .  This eliminates the need to cast the result of the expression and Flee will only compile the expression if evaluates to a boolean.

{{
ExpressionContext context = new ExpressionContext();
VariableCollection variables = context.Variables;
variables.Add("a", 100);
variables.Add("b", 1);
variables.Add("c", 24);
            
IGenericExpression<bool> e = context.CompileGeneric<bool>("(a = 100 OR b > 0) AND c <> 2");
bool result = e.Evaluate();
}}