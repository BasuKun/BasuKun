**Special functions in expressions**

Certain functions are treated specially by Flee and are built-in to all expressions.

**Conditional Operator**
Purpose: Returns one of two results based on a condition
Syntax: {{If(condition, whenTrue, whenFalse)}}
Notes: The conditional operator is lazy: it will only evaluate the expression that corresponds to the result of the condition.

Example:
{{
ExpressionContext context = new ExpressionContext();
VariableCollection variables = context.Variables;
variables.Add("a", 100);

// Return 123 if a is greater than 100; return -1 otherwise            
IGenericExpression<int> e = ExpressionFactory.CreateGeneric<int>("if(a > 100, 123, -1)", context);
int result = e.Evaluate();
}}

**Cast Operator**
Purpose: Performs an implicit or explicit cast of one value to another
Syntax: {{cast(value, type)}}

Example:
{{
ExpressionContext context = new ExpressionContext();
VariableCollection variables = context.Variables;
// Define a variable of type double
variables.Add("a", 123.45);

// Truncate it to an int
IGenericExpression<int> e = ExpressionFactory.CreateGeneric<int>("cast(a, int)", context);
int result = e.Evaluate();
}}