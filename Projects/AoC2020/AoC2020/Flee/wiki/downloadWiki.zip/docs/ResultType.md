**Using the result type option**

You can use the ResultType option to make the result of an expression be of a particular type.  Setting the option will put an **implicit** conversion to that type at the end of an expression.  If the conversion is not possible, an ExpressionCompileException will be thrown.

This sample shows how to use this property to make an expression always return a result of type Object

{{
ExpressionOptions options = new ExpressionOptions();
// Put an implicit convert to object at end of the expression
options.ResultType = typeof(object);
 
Expression e = new Expression("1+1", owner, options);
// The evaluator will now always be of the same type as the ResultType
ExpressionEvaluator<object> evaluator = (ExpressionEvaluator<object>) e.Evaluator;
// result will now contain the boxed integer 2
object result = evaluator();
}}