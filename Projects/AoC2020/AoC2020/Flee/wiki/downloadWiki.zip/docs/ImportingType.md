**Extending the members available to an expression**

