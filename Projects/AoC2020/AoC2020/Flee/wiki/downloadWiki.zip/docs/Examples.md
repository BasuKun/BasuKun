**Examples**

This page contains links to code samples that demonstrate how to use Flee:
	* [Getting started](GettingStarted): Quick guide to evaluating expressions
	* [Extending](ImportingTypes) the functions available to an expression
	* Using [Variables](ExpressionVariables) in expressions
	* Using Flee to evaluate [boolean expressions](BooleanExpression)
	* Using an [expression owner](ExpressionOwner)
	* Using the [calculation engine](CalculationEngine)
	* Retrieving values from [arrays and collections](IndexedMembers)
	* [Culture](CultureSensitiveExpressions) sensitive expressions
	* [Customizing](CustomizingParser) Flee's parser
	* Calling functions with a [variable](ParamArrayFunctions) number of arguments