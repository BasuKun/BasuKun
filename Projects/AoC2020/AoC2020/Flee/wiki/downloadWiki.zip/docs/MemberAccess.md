An expression can access all members of the expression owner.  By default, an expression will only allow access to the public members.  To control which members on the expression owner are accessible, you can use the {{OwnerMemberAccess}} property of the {{ExpressionOptions}} class.

In case you need more find-grained control, you can use the {{ExpressionOwnerMemberAccessAttribute}} to explicitly set the accessibility of  fields, properties, and methods on the owner.  The setting in the attribute overrides the setting in the {{ExpressionOptions}}.  This means that you can deny access to all non-public members **but** allow access to a specific non-public member by tagging it with the attribute.

{{
using Ciloci.Flee;
using System.Collections.Generic;

namespace ConsoleApplication1
{
    class ExpressionOwner
    {
        [ExpressionOwnerMemberAccess(false)](ExpressionOwnerMemberAccess(false))
        public int Func1()
        {

        }

        public int Func2(int i)
        {

        }
    }

    class Program
    {
        static void Main(string[]() args)
        {
            ExpressionContext context = new ExpressionContext();
            // Only allow access to public members on the owner (the default)
            context.Options.OwnerMemberAccess = System.Reflection.BindingFlags.Public;

            // This expression will compile
            IDynamicExpression e = ExpressionFactory.CreateDynamic("func2(100)", context);

            // This expression will throw a compile exception because of the overriding attribute on the function
            e = ExpressionFactory.CreateDynamic("func1()", context);
        }
    }
}

}}