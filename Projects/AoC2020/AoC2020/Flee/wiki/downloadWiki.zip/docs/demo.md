**Demo**

The demo application shows a practical usage of the library.  It generates an image by evaluating expressions for the red, green, and blue components where the expressions can reference the x and y co-ordinates of the current pixel and use all the functions of the System.Math class.

Using the demo will give you a good sense of how fast expressions can be evaluated. Even on my outdated computer at home, I still manage over a million evaluations per second. This means that, on a modern computer, you could generate an 800x600 image in under a second.

![Using the demo to generate an image](demo_DemoScreenshot.png)